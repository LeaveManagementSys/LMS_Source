package com.lms.service;

import java.util.List;

import com.lms.model.LeaveModel;


public interface LeaveService 
{
		public List<LeaveModel> retrieveLeaves();

}
