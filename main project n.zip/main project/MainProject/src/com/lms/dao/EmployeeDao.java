package com.lms.dao;

import java.sql.SQLException;

import java.util.List;

import com.lms.entities.Employee;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;
import com.lms.entities.User;

public interface EmployeeDao 
{
	
	public boolean employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException;
	public LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException;
	
	public boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException;
}
