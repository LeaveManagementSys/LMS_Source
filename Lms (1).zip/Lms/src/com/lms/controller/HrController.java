package com.lms.controller;

import java.util.Scanner;

import com.lms.services.HrServices;
import com.lms.view.HRView;

public class HrController 
{
	public static boolean addEmployee(int empId, String fName, String lName, String email, String password, String location, String designation,String address,int mobileNo) 
	{
		HrServices hrService = new HrServices();
		
		return HrServices.addEmployee(empId, fName, lName, email, password, location, designation,address,mobileNo);
	}
}
