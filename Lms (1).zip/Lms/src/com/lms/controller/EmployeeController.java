package com.lms.controller;

import java.util.Scanner;

import com.lms.services.EmployeeServices;
//import com.lms.service.EndUserService;

public class EmployeeController 
{
	EmployeeServices empService = new EmployeeServices();
	//EmployeeController emsc = new EmployeeController();
	EndUserController endControl = new EndUserController();
	
	public static boolean requestLeave(int leaveId, int employeeId, String leaveType, String designation, String fromDate, String toDate, String comment)
	{
		return EmployeeServices.requestLeave(leaveId, employeeId, leaveType, designation, fromDate, toDate, comment);
		
	}
}
