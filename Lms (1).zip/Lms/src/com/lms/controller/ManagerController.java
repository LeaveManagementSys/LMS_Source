package com.lms.controller;

import java.util.ArrayList;
import java.util.Scanner;

import com.lms.entities.Leave;
import com.lms.services.ManagerService;

public class ManagerController 
{
	ManagerService manService = new ManagerService();
	public ArrayList<Leave> getLeaveRequests() 
	{
		return manService.getLeaveRequests();
		
	}
}

	
