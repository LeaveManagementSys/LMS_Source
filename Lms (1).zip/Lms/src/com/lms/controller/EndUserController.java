package com.lms.controller;

import java.util.Scanner;
import com.lms.services.EndUserService;
import com.lms.view.EmployeeView;
import com.lms.view.HRView;
import com.lms.view.ManagerView;

public class EndUserController 
{
	static EndUserController lmsc = new EndUserController();
	
	public static void mainService() 
	{
		lmsc.loginService();

	}
	private void loginService() 
	{
		EndUserService lmss = new EndUserService();
		HRView hrView = new HRView();
		EmployeeView empView = new EmployeeView();
		ManagerView manView = new ManagerView();
		
		int resEmp = lmss.validateLogin();
		
		String empStr = String.valueOf(resEmp);
		
		if(empStr.substring(0, 3).equals("806"))
		{
			empView.employeeMenu();
		}
		
		if(empStr.substring(0, 3).equals("807"))
		{
			hrView.hrView();
		}
		
		if(empStr.substring(0, 3).equals("805"))
		{
			manView.managerMenu(resEmp);
		}
			
	}
}
