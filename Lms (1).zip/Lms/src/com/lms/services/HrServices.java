package com.lms.services;

import java.util.ArrayList;
import java.util.Scanner;

import com.lms.dao.HrDAO;
import com.lms.entities.Employee;
import com.lms.view.HRView;

public class HrServices 
{
	static ArrayList<Employee> empList = new ArrayList<>();
	
	HrDAO hrDao = new HrDAO();
	
	public static boolean addEmployee(int empId, String fName, String lName, String email, String password, String location, String designation,String address,int mobileNo)
	{
		return HrDAO.addEmployee(empId, fName, lName, email, password, location, designation,address,mobileNo);
	}
	
	public ArrayList<Employee> getEmpList()
	{
		HRView hrView = new HRView();
		return hrView.getEmpList();
	}
	public void deleteEmployee() 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee Id");
		int empId = sc.nextInt();	
	}
	public void updateEmployee()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Location");
		String location = sc.next();
		System.out.println("Enter Employee Designation");
		String designation = sc.nextLine();
		System.out.println("Enter Employee address");
		String address = sc.nextLine();

		System.out.println("Enter Employee mobileNo");
		int mobileNo = sc.nextInt();
		sc.next();
	}
	
}
