package com.lms.services;

import java.util.Scanner;

public class EndUserService 
{

	public int validateLogin() 
	{
		Scanner sc = new Scanner(System.in);
		int resultEmp = 0;
		int flag = 0;
		System.out.println("enter employee ID");
		int empid = sc.nextInt();
		System.out.println("enter employee password");
		String pass = sc.nextLine();
		sc.next();
		String empStr = String.valueOf(empid);
		if(empid != 0)
		{
			resultEmp = empid;
		}	
		return resultEmp;
		
	}

}
