package com.lms.services;

import java.util.ArrayList;
import java.util.Iterator;

import com.lms.dao.ManagerDAO;
import com.lms.entities.Leave;

public class ManagerService {

	ManagerDAO empDao = new ManagerDAO();
	public ArrayList<Leave> getLeaveRequests() 
	{
		
		EmployeeServices es = new EmployeeServices();
		ArrayList<Leave> leaveRqs = es.getLeaveReqs();
		
		return empDao.getLeaveRequests();
	}

}
