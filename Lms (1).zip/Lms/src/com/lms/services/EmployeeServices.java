package com.lms.services;

import java.util.ArrayList;
import java.util.Scanner;

import com.lms.dao.EmployeeDAO;
import com.lms.entities.Leave;

public class EmployeeServices 
{
	ArrayList<Leave> leaveList = new ArrayList();
	EmployeeDAO empDao = new EmployeeDAO();
	
	public ArrayList<Leave> getLeaveReqs()
	{
		return leaveList;
	}
	public void leaveList()
	{
		ArrayList<String> list=new ArrayList<String>(); 

		list.add("1.Sick Leave"+"\n");   
		list.add("2.Privileage Leave"+"\n");    
		list.add("3.Casual Leave"+"\n");    
		System.out.println(list);  
		
			
	}
	
	public void checkLeaveBalance()
	{
		//
	}
	public void getRequestStatus()
	{
		
	}

	public static boolean requestLeave(int leaveId, int employeeId, String leaveType, String designation, String fromDate, String toDate, String comment)
	{
		return EmployeeDAO.requestLeave(leaveId, employeeId, leaveType, designation, fromDate, toDate, comment);
	}
}
