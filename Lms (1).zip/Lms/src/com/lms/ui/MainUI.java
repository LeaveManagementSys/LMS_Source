package com.lms.ui;

import com.lms.controller.EndUserController;

public class MainUI {

	public static void main(String[] args) {
		
		EndUserController.mainService();

	}

}
