package com.lms.view;

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.text.html.HTMLDocument.Iterator;

import com.lms.controller.EndUserController;
import com.lms.controller.HrController;
import com.lms.dao.HrDAO;
import com.lms.entities.Employee;
import com.lms.services.HrServices;

public class HRView 
{

	ArrayList<Employee> empList = new ArrayList<>();
	HrDAO hrDao = new HrDAO();
	HrServices hrService = new HrServices();
	
	
	public void hrView() 
	{
		HRView hrView = new HRView();
		EndUserController euc = new EndUserController();
		
		while(true)
		{
			
			System.out.println("Please Select the options");
			Scanner sc = new Scanner(System.in);
			System.out.println("1.Add Employee 2.Delete Employee 3.Update Employee Details 4. Logout");
			int ch = sc.nextInt();
			
			if(ch == 1)
			{
				hrView.addEmployeeView();
			}
			
			if(ch == 2)
			{
				hrService.deleteEmployee();
			}
			
			if(ch == 3)
			{
				hrService.updateEmployee();
			}
			
			if(ch == 4)
			{
				euc.mainService();
				break;
			}
		}
	}
	
	
	public boolean addEmployeeView() 
	{
		HrController hrControl = new HrController();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee Id");
		int empId = sc.nextInt();
		
		
		System.out.println("Enter Employee First Name");
		String fName = sc.nextLine();
		sc.nextLine();
		
		System.out.println("Enter Employee Last Name");
		String lName = sc.next();
		
		System.out.println("Enter Employee Email Id");
		String email = sc.next();
		
		System.out.println("Enter Employee password");
		String password = sc.next();
		sc.nextLine();
		
		System.out.println("Enter Employee Location");
		String location = sc.nextLine();
		
		System.out.println("Enter Employee Designation");
		String designation = sc.nextLine();

		System.out.println("Enter Employee address");
		String address = sc.nextLine();

		System.out.println("Enter Employee mobileNo");
		int mobileNo = sc.nextInt();
		
		boolean check = HrController.addEmployee(empId, fName, lName, email, password, location, designation,address,mobileNo);
		if(check == true)
			System.out.println("Employee Created Successfully");
		else
			System.out.println("Employee Creation Failed");
		return check;
	}
	public ArrayList<Employee> getEmpList() 
	{
		
		return empList;
	}
	
}
