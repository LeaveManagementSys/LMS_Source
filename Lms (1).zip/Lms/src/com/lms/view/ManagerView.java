package com.lms.view;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.lms.controller.EndUserController;
import com.lms.controller.ManagerController;
import com.lms.entities.Leave;
import com.lms.services.ManagerService;

public class ManagerView 
{
	ManagerController manController = new ManagerController();
	EndUserController endControl = new EndUserController();
	
	public void managerMenu(int resEmp) 
	{
		ManagerView mView = new ManagerView();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please Select the options");

		System.out.println("1.Get Leave Requests 2.Logout");
		int ch = sc.nextInt();
		
		if(ch == 1)
		{
			mView.getLeaveRequests();
		}
		if(ch == 2)
		{
			endControl.mainService();
		}
		
	}

	private void getLeaveRequests() 
	{
		
		ArrayList<Leave> leaveRqs = new ArrayList();
		
		leaveRqs = manController.getLeaveRequests();
		
		for (int i = 0; i < leaveRqs.size(); i++)  
            System.out.print("Leave Id : " + leaveRqs.get(i).getLeaveId() + ", Emp Id : " +leaveRqs.get(i).getEmpId() + ", Leave Type : " + leaveRqs.get(i).getLeaveType() + ", From : " + leaveRqs.get(i).getFromDate() + ", To : " + leaveRqs.get(i).getToDate() + ", Desc : " + leaveRqs.get(i).getLeaveDesc() + ", Blance Leaves : " + leaveRqs.get(i).getLeaveBalances()+ "\n");
		
		System.out.println("Enter your Option");
		System.out.println("1. Accept 2. Reject 3. Hold");
		
	}

}
