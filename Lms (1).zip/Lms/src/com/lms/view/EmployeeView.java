package com.lms.view;

import java.util.ArrayList;
import java.util.Scanner;

import com.lms.controller.EmployeeController;
import com.lms.controller.EndUserController;

public class EmployeeView 
{
	EndUserController euc = new EndUserController();
	EmployeeController empControl = new EmployeeController();
	public void employeeMenu() 
	{
		EmployeeView empView = new EmployeeView();
		
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Please Select the options");

			System.out.println("1.Request Leave 2.Select type of leave 3.View request status 4.Logout");
			int ch = sc.nextInt();
			
			if(ch == 1)
			{
				empView.requestLeave();
			}
			if(ch==2)
			{
				empView.leaveList();
			}
			if(ch == 4)
			{
				euc.mainService();
				break;
			}
		}
		
	}

	private void requestLeave()
	{
		
		Scanner sc = new Scanner(System.in);
		int resultEmp = 0;
		int flag = 0;
		
		System.out.println("Enter Leave ID");
		int leaveId = sc.nextInt();
		
		System.out.println("Enter employee ID");
		int employeeId = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Type of Leave");
		String leaveType = sc.nextLine();
		
		System.out.println("Designation");
		String designation=sc.nextLine();
		
		System.out.println("From date");
		String fromDate = sc.next();
		
		System.out.println("To date");
		String toDate = sc.next();
		
		System.out.println("Comment");
		String comment = sc.nextLine();
		sc.next();
		
		boolean check = EmployeeController.requestLeave(leaveId, employeeId, leaveType, designation, fromDate, toDate, comment);
		if(check == true)
			System.out.println("Leave Request Sent Successfully");
		else
			System.out.println("Leave Request Sent Failed");
	}
	public void leaveList()
	{
		ArrayList<String> list=new ArrayList<String>(); 
		
	    list.add("1.Sick Leave");   
	    list.add("2.Privileage Leave");    
	    list.add("3.Casual Leave");    
	    for(String arraylist: list)
		{
			System.out.println(arraylist);
		}
	}
	
}
