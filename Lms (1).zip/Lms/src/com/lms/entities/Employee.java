package com.lms.entities;

public class Employee 
{
	private int empId;
	private String firstName;
	private String lastName;
	private String email;
	private String location;
	private String password;
	private String designation;
	private String address;
	private int mobileNo;
	
	
	public Employee(int empId, String firstName, String lastName, String email, String password, String location,
			String designation,String address,int mobileNo) 
	{
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.location = location;
		this.designation = designation;
		this.address=address;
		this.mobileNo=mobileNo;
		
	}
	public int getEmp_id() {
		return empId;
	}
	public void setEmpId(int emd) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getEmpId() {
		return empId;
	}
	
	
}
