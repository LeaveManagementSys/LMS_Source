package com.lms.entities;

public class Leave 
{
	
	private int leaveId;
	private int empId;
	private String leaveType;
	private String fromDate;
	private String toDate;
	private String designation;
	private String leaveDesc;
	private int leaveBalances = 20;
	private String leaveStatus;
	
	public Leave(int leaveId, int empId, String leaveType, String designation, String fromDate, String toDate,
			String leaveDesc) {
		
		this.leaveId = leaveId;
		this.empId = empId;
		this.leaveType = leaveType;
		this.designation = designation;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.leaveDesc = leaveDesc;
		
	}
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getLeaveDesc() {
		return leaveDesc;
	}
	public void setLeaveDesc(String leaveDesc) {
		this.leaveDesc = leaveDesc;
	}
	public int getLeaveBalances() {
		return leaveBalances;
	}
	public void setLeaveBalances(int leaveBalances) 
	{
		this.leaveBalances = leaveBalances;
	}
	public String getLeaveStatus() 
	{
		return leaveStatus;
	}
	public void setLeaveStatus(String leaveStatus) 
	{
		this.leaveStatus = leaveStatus;
	}
	

}
