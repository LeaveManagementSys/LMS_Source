package com.lms.dao;

import java.util.ArrayList;

import com.lms.entities.Leave;

public class EmployeeDAO 
{
	static ArrayList<Leave> leaveList = new ArrayList();
	public static boolean requestLeave(int leaveId, int employeeId, String leaveType, String designation, String fromDate, String toDate, String comment)
	{
		
		boolean check = leaveList.add(new Leave(leaveId, employeeId, leaveType, designation, fromDate, toDate, comment));
		for (int i = 0; i < leaveList.size(); i++)  
            System.out.print(leaveList.get(i).getLeaveType() + " ");
		return check;
	}
	public ArrayList<Leave> getLeaveList() 
	{
		return leaveList;
	}
	
	
	
}
