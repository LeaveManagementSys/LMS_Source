package com.lms.dao;

import java.util.ArrayList;

import com.lms.entities.Leave;

public class ManagerDAO 
{
	EmployeeDAO empDao = new EmployeeDAO();
	ArrayList<Leave> leaveList = new ArrayList<Leave>();
	public ArrayList<Leave> getLeaveRequests() 
	{
		
		return leaveList = empDao.getLeaveList();
	}
	
}
