package com.lms.dao;

import java.util.ArrayList;

import com.lms.entities.Employee;

public class HrDAO {

	static ArrayList<Employee> empList = new ArrayList<>();
	
	public static boolean addEmployee(int empId, String fName, String lName, String email, String password, String location, String designation,String address,int mobileNo) 
	{
		boolean check = empList.add(new Employee(empId, fName, lName, email, password, location, designation,address,mobileNo));
		for (int i = 0; i < empList.size(); i++)  
            System.out.print(empList.get(i).getEmp_id() + "\n");  
		return check;
	}
}
