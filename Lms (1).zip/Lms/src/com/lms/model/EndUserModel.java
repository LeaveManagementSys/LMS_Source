package com.lms.model;

public class EndUserModel 
{
	public EndUserModel() {}
	private int empid;
	private String emppassword;
	public int getUserName() {
		return empid;
	}
	public void setUserName(int empid) {
		this.empid = empid;
	}
	public String getPassword() {
		return emppassword;
	}
	public void setPassword(String emppassword) {
		this.emppassword = emppassword;
	}
}
