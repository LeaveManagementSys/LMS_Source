package com.virtusa.ui;

import com.virtusa.view.HrMainView;

public class Hrui {
	public static void main(String[] args) {
		
		HrMainView hrmainview=new HrMainView();
		hrmainview.hrMainView();
	}
	
}
