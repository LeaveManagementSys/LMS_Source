package com.virtusa.exceptions;

public class ZeroBalanceException {

}
