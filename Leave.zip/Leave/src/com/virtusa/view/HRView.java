package com.virtusa.view;

public class HRView {

	public void hrHomePage() {
		System.out.println("*********HR View********");
		System.out.println("1.Create employee");
		System.out.println("2.Delete employee");
		System.out.println("3.Upate details of employee");
		System.out.println("4.Track leave status");
	}
}
