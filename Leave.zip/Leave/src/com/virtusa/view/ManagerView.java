package com.virtusa.view;

public class ManagerView {


	public void managerHomePage() {
		System.out.println("********Manager View*********");
		System.out.println("1.Check leave request");
		System.out.println("2.Logout");
	}
}
