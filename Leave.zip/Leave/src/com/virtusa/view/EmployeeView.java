package com.virtusa.view;

public class EmployeeView {

	public void employeeHomePage() {
		System.out.println("********Employee View********");
		System.out.println("1.Check leave balences");
		System.out.println("2.Apply leave");
		System.out.println("3.Approved leaves");
		System.out.println("4.cancelled leaves");
		System.out.println("5.Pending leaves");
		System.out.println("6.Logout");
	}
}
