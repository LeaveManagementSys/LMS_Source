package com.virtusa.dao;

public class LeaveDAOImp {

}
