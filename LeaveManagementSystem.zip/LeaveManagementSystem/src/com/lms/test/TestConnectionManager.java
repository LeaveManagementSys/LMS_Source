package com.lms.test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.SQLException;

import com.lms.integrate.*;
import org.junit.Test;

public class TestConnectionManager 
{
	@Test
	public void testOpenConnection_positive() 
	{
		try 
		{
			Connection connection=ConnectionManager.openConnection();
			assertEquals(true,connection!=null);
		} catch (ClassNotFoundException | SQLException e) {
			assertTrue(false);
		}
	
	}
}
