package com.lms.validation;

public class EmployeeModelValidation {

}
