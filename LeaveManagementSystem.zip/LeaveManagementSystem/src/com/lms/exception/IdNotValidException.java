package com.lms.exception;

public class IdNotValidException extends Exception
{
	String message;

	public IdNotValidException(String message) 
	{
		super();
		this.message = message;
	}

	public String getMessage() 
	{
		return message;
	}
}
