package com.lms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lms.entities.Employee;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;
import com.lms.integrate.ConnectionManager;

public class JDBCEmployeeDao implements EmployeeDao
{


	@Override
	public Employee getEmployeeById(int empId) throws ClassNotFoundException, SQLException 
	{
		
		Employee empObj = new Employee();
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement statement = connection.prepareStatement("select * from employees where emp_id = ?");
		
		statement.setInt(1, empId);
		ResultSet resultSet = statement.executeQuery();
		while(resultSet.next())
			empObj = new Employee(resultSet.getInt("employee_id"), resultSet.getString("first_name"), resultSet.getString("last_name"), resultSet.getString("email"), resultSet.getString("location"));
		
		return empObj;
	}
	
	



	
	
}