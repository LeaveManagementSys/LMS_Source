package com.lms.dao;


import java.sql.SQLException;

public interface UserDao 
{
	public boolean employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException;
}
