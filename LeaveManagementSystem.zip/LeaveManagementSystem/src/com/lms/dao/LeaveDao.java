package com.lms.dao;

import java.sql.SQLException;
import java.util.List;

import com.lms.entities.Leaves;



public interface LeaveDao 
{
	public static List<Leaves> getAllLeaveTypes() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	int requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException;
}
