package com.lms.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.lms.entities.LeaveBalance;
import com.lms.service.LeaveServiceImpl;

/**
 * Servlet implementation class CheckLeaveBalanceController
 */
@WebServlet("/CheckLeaveBalanceController")
public class CheckLeaveBalanceController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		Logger logger = Logger.getLogger(CheckLeaveBalanceController.class);
		BasicConfigurator.configure();
		HttpSession session = request.getSession();
		int empId = (int) session.getAttribute("empId");
		LeaveBalance leaveBalance = null;
		
		LeaveServiceImpl leaveService = new LeaveServiceImpl();
		try 
		{
			leaveBalance = leaveService.viewLeaveBalances(empId);
			request.setAttribute("leaveBalance", leaveBalance);
			request.getRequestDispatcher("/employeePage.jsp").forward(request, response);
		
		} catch (ClassNotFoundException | SQLException e) {
			
			logger.fatal(e);
		}
		
		
		
		
	}

}
