package com.lms.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lms.dao.JDBCEmployeeDao;
import com.lms.dao.JDBCLeaveDao;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;

public class EmployeeServiceImp implements EmployeeService
{
	JDBCLeaveDao leaveDao = new JDBCLeaveDao();
	public ArrayList<Leaves> viewRequestStatus(int empId) throws ClassNotFoundException, SQLException {
		
		ResultSet resultSet = leaveDao.viewRequestStatus(empId);
		ArrayList<Leaves> leaveList = new ArrayList();
		while(resultSet.next())
		{
			leaveList.add(new Leaves(resultSet.getInt(1),resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(7), resultSet.getString(8)));
		}
		
		return leaveList;
	}
	
	public boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException {
		
		int result = leaveDao.requestLeave(leave, empId);
		boolean status = false;
		if(result > 0)
		{
			status = true;
		}
		return status;
	}

}