package com.lms.service;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import com.lms.dao.JDBCLeaveDao;
import com.lms.dao.LeaveDao;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;
import com.lms.helper.FactoryEmployeeDb;


public class LeaveServiceImpl implements LeaveService 
{
	private LeaveDao leaveDAO;
	JDBCLeaveDao leaveDao = new JDBCLeaveDao();
	public LeaveServiceImpl() 
	{
		this.leaveDAO=FactoryEmployeeDb.createLeavesDAO();
		
	}
	@Override
	
	
	public LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException {
		
		LeaveBalance leaveBalance = null;
		ResultSet resultSet = leaveDao.viewLeaveBalances(empId);
		if(resultSet.next())
		{
			System.out.println(resultSet.getInt(2) + " " + resultSet.getInt(3) + " " + resultSet.getInt(4));
			leaveBalance = new LeaveBalance(resultSet.getInt(2), resultSet.getInt(3), resultSet.getInt(4));
		}
		return leaveBalance;
	}
	
}
