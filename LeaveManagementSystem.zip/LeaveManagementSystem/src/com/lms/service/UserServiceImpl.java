package com.lms.service;

import java.sql.SQLException;

import com.lms.dao.JDBCEmployeeDao;
import com.lms.dao.JDBCUserDao;

public class UserServiceImpl implements UserService 
{
	JDBCUserDao userDao = new JDBCUserDao();
	public String employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException 
	{
		String empType = "";
		String empStr = String.valueOf(empId);
		if(userDao.employeeLogin(empId, password).next()) // if any record present in data base status will become true
		{
			if(empStr.substring(0, 3).equals("806"))
			{
				empType = "emp";
				//validate with employee table
			}
			if(empStr.substring(0, 3).equals("807"))
			{
				empType = "hr";
			}
			if(empStr.substring(0, 3).equals("805"))
			{
				empType = "mgr";
			}
		}
		return empType;
	}
}
