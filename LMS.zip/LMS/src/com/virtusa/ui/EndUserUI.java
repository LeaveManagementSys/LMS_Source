package com.virtusa.ui;

import java.sql.SQLException;

import com.virtusa.view.EmployeeView;
import com.virtusa.view.MainView;

public class EndUserUI {
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
		MainView mainview=new MainView();
		mainview.mainView();
	}

}
