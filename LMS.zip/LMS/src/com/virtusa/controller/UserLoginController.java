package com.virtusa.controller;

import java.sql.SQLException;


import com.virtusa.exception.UserException;
import com.virtusa.helper.UserData;
import com.virtusa.model.UserModel;
import com.virtusa.service.UserService;
import com.virtusa.view.EmployeeView;

import com.virtusa.view.MainView;
import com.virtusa.view.ManagerView;

public class UserLoginController {
	
	private UserService userService;
	public UserLoginController() {
		this.userService=UserData.createUserService();		
	}
	
	public void userVerification(UserModel usermodel) throws ClassNotFoundException, SQLException {
	
		String userType=
				userService.authenticateService(usermodel);	
		
		if(userType.contentEquals("EMPLOYEE")) {
			EmployeeView employeeView=new EmployeeView();
			employeeView.employeeMenu();
		    }
		
		if(userType.contentEquals("MANAGER")) {
			ManagerView managerView=new ManagerView();
			managerView.ManagerPage();
		    }
		
		if(userType.contentEquals("HR")) {
			MainView mainView=new MainView();
			mainView.mainView();
		    }		
}

}
