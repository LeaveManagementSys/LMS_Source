package com.virtusa.controller;

import java.sql.SQLException;


import com.virtusa.DAO.ManagerDAO;
import com.virtusa.DAO.ManagerDAOImpl;
import com.virtusa.service.ManagerService;
import com.virtusa.service.ManagerServiceImpl;

public class ManagerController {
	
	public void viewListOfLeaveRequests() throws ClassNotFoundException, SQLException {
		ManagerDAOImpl managerDAO=new ManagerDAOImpl();
		managerDAO.getListOfLeaves();
		
		
	}
	public void leavebalances(int empId) throws ClassNotFoundException, SQLException {
		ManagerDAOImpl managerDAO=new ManagerDAOImpl();
		managerDAO.checkLeaveBalances(empId);
		
		ManagerServiceImpl managerService=new ManagerServiceImpl();
		managerService.leaveBalances();
	}
	public void approveLeave(int empId) throws ClassNotFoundException, SQLException {
		ManagerServiceImpl managerService=new ManagerServiceImpl();
		managerService.leaveApproval(empId);
	}
	public void rejectLeave(int empId) throws ClassNotFoundException, SQLException {
		ManagerServiceImpl managerService=new ManagerServiceImpl();
		managerService.leaveRejection(empId);
	}

}
