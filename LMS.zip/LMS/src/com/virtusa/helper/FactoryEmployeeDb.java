package com.virtusa.helper;

import com.virtusa.DAO.LeaveDao;
import com.virtusa.DAO.LeaveDaoImpl;
import com.virtusa.service.LeaveService;
import com.virtusa.service.LeaveServiceImpl;

public class FactoryEmployeeDb {
	
	public static LeaveDao createLeavesDAO(){
		LeaveDao leaveDAO=new LeaveDaoImpl();
		return leaveDAO;
		
	}
	public static LeaveService createDepartmentsService(){
		LeaveService leaveService=new LeaveServiceImpl();
		return leaveService;
	}

}
