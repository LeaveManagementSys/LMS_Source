package com.virtusa.view;

import java.sql.Date;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Scanner;

import com.virtusa.controller.EmployeeController;
import com.virtusa.entities.LeaveBalance;
import com.virtusa.entities.Leaves;


public class EmployeeView 
{
	EmployeeController empController = new EmployeeController();
	
	public void employeeMenu() throws ClassNotFoundException, SQLException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("1.Check Leave Balances 2.Request Leave  3.View Request Status ");
		
		
		System.out.print("\nOption:");
		int option=sc.nextInt();
		
		switch(option) {
		
		case 1:viewLeaveBalance();
		       break;
		case 2:
			   requestLeave();
			   break;
		case 3:viewRequestStatus();
			   break;
		}
		
	}
	private void viewRequestStatus() throws ClassNotFoundException, SQLException 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Number");
		int empId = sc.nextInt();
		ArrayList<Leaves> leaveList= empController.viewRequestStatus(empId);
		
		for (Leaves l : leaveList) 
		{
            System.out.print("For Leave Request from " + l.getFromDate() + " to " + l.getToDate() + " of type " + l.getLeaveType() + " is with status " + l.getLeaveStatus()+ "\n");
		}
		employeeMenu();
		
	}
	private void requestLeave() throws ClassNotFoundException, SQLException 
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Employee Number");
		int empId = sc.nextInt();
		
		System.out.println("Enter Leave Type");
		String leaveType = sc.next();
		sc.nextLine();
		
		System.out.println("From date");
		String from_date = sc.next();
		
		System.out.println("To date");
		String to_date = sc.next();
		
		System.out.println("Designation");
		String designation = sc.next();
		sc.nextLine();
		
		System.out.println("Leave Description");
		String description = sc.nextLine();
		//sc.close();
		
		Leaves leave = new Leaves(leaveType, from_date, to_date, designation, description);
		if(empController.requestLeave(leave, empId))
		{
			System.out.println("Leave request sent");
		}
		
		employeeMenu();
		
	}
	private void viewLeaveBalance() throws ClassNotFoundException, SQLException 
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Employee Number");
		int empId = sc.nextInt();
		
		LeaveBalance leave = empController.viewLeaveBalances(empId);
		System.out.println("Your Leave Balances are: ");
		System.out.println("Sick Leaves: " + leave.getSickLeave() + " Earned Leaves are: " + leave.getEarnedLeave() + " Bereavement Leaves are: " + leave.getBereavementLeave());
		
		employeeMenu();
			
	}


}
	