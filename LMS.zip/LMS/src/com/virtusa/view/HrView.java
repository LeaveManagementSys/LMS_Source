package com.virtusa.view;

import com.virtusa.model.InsertEmployeeModel;

import com.virtusa.model.RetriveEmployeeModel;
import com.virtusa.model.UpdateEmpPhoneNumberModel;
import com.virtusa.model.UpdateEmployeeDesignationModel;
import com.virtusa.model.UpdateEmployeeSalaryModel;


public class HrView {
	  
	    public void showRegistrationSuccess(InsertEmployeeModel insertemployeemodel) {
	    	MainView  mainView=new MainView();
			System.out.println("\n Registration successful for employee id=>"+insertemployeemodel.getEmployeeId());
			mainView.mainView();
		}
	    
    public void showRegistrationfailure(InsertEmployeeModel insertemployeemodel)
    {
        	 MainView  mainView=new MainView();
			System.out.println("\n Registration not successful for employee id=>"+insertemployeemodel.getEmployeeId());
			mainView.mainView();
		}	 
	 public void showSalaryUpdateSuccess(UpdateEmployeeSalaryModel updateempsalarymodel)
	 {
		 MainView  mainView=new MainView();	 
		   /* int a=10;
			System.out.println(a);
			*/
		 System.out.println("\n Salary successful updated for employee id=>"+updateempsalarymodel.getEmployeeId());
		 mainView.mainView();
	 }
	 
	 public void showSalaryUpdateFailure(UpdateEmployeeSalaryModel updateempsalarymodel)
	 {
		 MainView  mainView=new MainView();
		 System.out.println("\n Salary updated failed for employee id=>"+updateempsalarymodel.getEmployeeId());
		 mainView.mainView();
		 
	 }
	 public void showDeleteSuccess(RetriveEmployeeModel retriveEmployeemodel)
	 {
		 MainView  mainView=new MainView();
		 System.out.println("\n Employee record deleted for employee id=>"+ retriveEmployeemodel.getEmployeeId());
		 mainView.mainView();
	 }
	 
	 public void showDeleteFailure(RetriveEmployeeModel retriveEmployeemodel)
	 {
		 MainView  mainView=new MainView();
		 System.out.println("\n Employee record deletion failed for employee id=>"+retriveEmployeemodel.getEmployeeId());
	 }
	 
	 public void showPhoneNumberUpdateSuccess(UpdateEmpPhoneNumberModel updateempphonenumbermodel)
	 {
		 MainView  mainView=new MainView();
		 System.out.println("\n Employee phone number update  success for employee id=>"+ updateempphonenumbermodel.getEmployeeId()+"to"+" "+updateempphonenumbermodel.getNewphoneNumber());
		 mainView.mainView();
	 }
	 
	 public void showPhoneNumberUpdateFailure(UpdateEmpPhoneNumberModel updateempphonenumbermodel)
	 {
		 MainView  mainView=new MainView();
		 System.out.println("\n Employee phone number update failed for employee id=>"+updateempphonenumbermodel.getEmployeeId()+"to"+" "+updateempphonenumbermodel.getNewphoneNumber());
		 mainView.mainView();
	 }	 
	 public void showDesignationUpdateSuccess(UpdateEmployeeDesignationModel updateemployeedesgmodel)
	 {
		 MainView  mainView=new MainView();
		 System.out.println("\n Employee designation update  success for employee id=>"+ updateemployeedesgmodel.getEmployeeId()+"to"+" "+updateemployeedesgmodel.getUpdateDesignation());
		 mainView.mainView();
	 }
	  public void showDesignationUpdateFailure(UpdateEmployeeDesignationModel updateemployeedesgmodel)
	  {
		  MainView  mainView=new MainView();
		  System.out.println("\n Employee designation update NOT success for employee id=>"+ updateemployeedesgmodel.getEmployeeId()+"to"+" "+updateemployeedesgmodel.getUpdateDesignation());
		  mainView.mainView();
	  }
	    
}
