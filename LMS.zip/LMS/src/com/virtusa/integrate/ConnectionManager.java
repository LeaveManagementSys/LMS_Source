package com.virtusa.integrate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager 
{
	private static Connection connection=null;
	static Connection con = null;
	public static Connection openConnection() 
			throws ClassNotFoundException,SQLException 
	{

		String url = "jdbc:mysql://localhost:3306/lms";
		String username = "root";
		String pass = "system";
		
		System.out.println("con " + con);
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url,username,pass);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
		
	}
	
	public static void closeConnection() throws SQLException{
		
		con.close();
	}
}
