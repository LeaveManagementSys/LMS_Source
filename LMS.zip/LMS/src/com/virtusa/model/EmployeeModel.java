package com.virtusa.model;

public class EmployeeModel 
{
	private String username;
	private String password;
	
	private LeaveModel leaveModel;
	public EmployeeModel() {
	}
	

	@Override
	public String toString() {
		return "EmployeeModel [username=" + username + ", password=" + password + ", leaveModel=" + leaveModel + "]";
	}


	public String getUsername() {
		return username;
	}


	public String getPassword() {
		return password;
	}


	public LeaveModel getLeaveModel() {
		return leaveModel;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((leaveModel == null) ? 0 : leaveModel.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeModel other = (EmployeeModel) obj;
		if (leaveModel == null) {
			if (other.leaveModel != null)
				return false;
		} else if (!leaveModel.equals(other.leaveModel))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}



	
}
