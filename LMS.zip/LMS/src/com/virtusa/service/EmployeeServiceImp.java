package com.virtusa.service;

import java.sql.ResultSet;



import java.sql.SQLException;
import java.util.ArrayList;


import com.virtusa.DAO.EmployeeDao;
import com.virtusa.DAO.EmployeeDaoImpl;
import com.virtusa.entities.LeaveBalance;
import com.virtusa.entities.Leaves;


public class EmployeeServiceImp
{
	EmployeeDaoImpl empDao = new EmployeeDaoImpl();
	
	public ArrayList<Leaves> viewRequestStatus(int empId) throws ClassNotFoundException, SQLException {
		
		ResultSet resultSet = empDao.viewRequestStatus(empId);
		ArrayList<Leaves> leaveList = new ArrayList();
		while(resultSet.next())
		{
			leaveList.add(new Leaves(resultSet.getInt(1),resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(7), resultSet.getString(8)));
		}
		
		return leaveList;
	}
	public LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException {
		
		LeaveBalance leaveBalance = null;
		ResultSet resultSet = empDao.viewLeaveBalances(empId);
		if(resultSet.next())
		{
			System.out.println(resultSet.getInt(1) + "" + resultSet.getInt(2) + "" + resultSet.getInt(3));
			leaveBalance = new LeaveBalance(resultSet.getInt(2), resultSet.getInt(3), resultSet.getInt(4));
		}
		return leaveBalance;
	}
	public boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException {
		
		int result = empDao.requestLeave(leave, empId);
		boolean status = false;
		if(result > 0)
		{
			status = true;
		}
		return status;
	}
}