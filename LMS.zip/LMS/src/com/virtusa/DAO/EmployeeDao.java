package com.virtusa.DAO;

import java.sql.ResultSet;


import java.sql.SQLException;

import java.util.List;

import com.virtusa.entities.Employee;
import com.virtusa.entities.LeaveBalance;
import com.virtusa.entities.Leaves;


public interface EmployeeDao 
{
	public ResultSet viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException;
	public int requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException;
	public ResultSet viewRequestStatus(int empId) throws ClassNotFoundException, SQLException; 
}
