package com.lms.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lms.dao.JDBCEmployeeDao;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;

public interface EmployeeService 
{
	JDBCEmployeeDao empDao = new JDBCEmployeeDao();
	
	public abstract ArrayList<Leaves> viewRequestStatus(int empId) throws ClassNotFoundException, SQLException;
		
	public abstract LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException;
	
	public abstract boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException; 
}
