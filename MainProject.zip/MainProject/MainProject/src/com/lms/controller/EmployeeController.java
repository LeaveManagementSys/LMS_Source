package com.lms.controller;

import java.sql.SQLException;

import java.util.ArrayList;

import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;
import com.lms.service.EmployeeService;
import com.lms.service.EmployeeServiceImp;

public class EmployeeController 
{
	EmployeeServiceImp empService = new EmployeeServiceImp();
	
	public ArrayList<Leaves> viewRequestStatus(int empId) throws ClassNotFoundException, SQLException {
		
		return empService.viewRequestStatus(empId);
	}
	public LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException {
		
		return empService.viewLeaveBalances(empId);
	}
	public boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException {
		
		return empService.requestLeave(leave, empId);
	}
	
}
