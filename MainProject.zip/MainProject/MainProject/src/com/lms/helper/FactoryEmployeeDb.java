package com.lms.helper;


import com.lms.dao.JDBCEmployeeDao;

import com.lms.dao.JDBCLeaveDao;
import com.lms.dao.LeaveDao;
import com.lms.service.EmployeeService;
import com.lms.service.LeaveService;
import com.lms.service.LeaveServiceImpl;




public class FactoryEmployeeDb 
{
	public static LeaveDao createLeavesDAO(){
		LeaveDao leaveDAO=new JDBCLeaveDao();
		return leaveDAO;
		
	}
	public static LeaveService createDepartmentsService(){
		LeaveService leaveService=new LeaveServiceImpl();
		return leaveService;
	}
}
