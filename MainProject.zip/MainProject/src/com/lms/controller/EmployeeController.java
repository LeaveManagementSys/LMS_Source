package com.lms.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;
import com.lms.service.EmployeeService;

public class EmployeeController 
{
	EmployeeService empService = new EmployeeService();
	public boolean employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException 
	{
		return empService.employeeLogin(empId, password);
	}
	public ArrayList<Leaves> viewRequestStatus(int empId) throws ClassNotFoundException, SQLException {
		
		return empService.viewRequestStatus(empId);
	}
	public LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException {
		
		return empService.viewLeaveBalances(empId);
	}
	public boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException {
		
		return empService.requestLeave(leave, empId);
	}
	
}
