package com.lms.controller;

import com.lms.model.UserModel;
import com.lms.service.UserService;

public class UserController {

	
	public void userAuthentication(String UserName,String Password) {
		UserModel userModel=new UserModel();
		userModel.setUserName(UserName);
		userModel.setPassword(Password);
		
		UserService userService=new UserService();
		userService.validateUser(userModel);
	}
}
