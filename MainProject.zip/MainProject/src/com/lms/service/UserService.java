package com.lms.service;

import com.lms.dao.UserDAOImpl;
import com.lms.model.UserModel;

public class UserService {
 
	
	public String validateUser(UserModel userModel) {
		
		boolean result=false;
		for(User user:usersList) {	
			if(user.getUserName().equals(userName)) {
				
				if(user.getPassword().equals(password)) {
					result= true;
										
				}
			}
		}
		return null;
		
	}
}
