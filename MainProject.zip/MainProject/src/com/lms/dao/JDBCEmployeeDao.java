package com.lms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lms.entities.Employee;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;
import com.lms.integrate.ConnectionManager;

public class JDBCEmployeeDao implements EmployeeDao
{
	public boolean requestLeave()
	{
		return false;
	}

	@Override
	public ResultSet employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException 
	{
		System.out.println(empId + " " + password);
		boolean status = false;
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement statement = connection.prepareStatement("select * from employee where emp_id = ? and password = ?");
		
		statement.setInt(1, empId);
		statement.setString(2, password);
		ResultSet resultSet = statement.executeQuery();
	
		return resultSet;
	}

	public ResultSet viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException 
	{
		int status = 0;
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement statement = connection.prepareStatement("select * from leavebalance where emp_id = ?");
		statement.setInt(1, empId);
		ResultSet resultSet = statement.executeQuery();
	
		return resultSet;
	}

	@Override
	public int requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException 
	{
		boolean status = false;
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement statement = connection.prepareStatement("insert into leaves_table values(0,?,?,?,?,?,?,?)");
		statement.setInt(1, empId);
		statement.setString(2, leave.getLeaveType());
		statement.setString(3, leave.getFromDate());
		statement.setString(4, leave.getToDate());
		statement.setString(5, leave.getDesignation());
		statement.setString(6, leave.getLeaveDesc());
		statement.setString(7, "Hold");
		int result = statement.executeUpdate();
		
		return result;
	}

	public ResultSet viewRequestStatus(int empId) throws ClassNotFoundException, SQLException 
	{
		
		Leaves leave = null;
		
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement statement = connection.prepareStatement("select * from leaves_table where emp_id = ?");
		statement.setInt(1, empId);
		ResultSet resultSet = statement.executeQuery();
		
		return resultSet;
	}
	
}