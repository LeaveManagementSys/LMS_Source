package com.lms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;

import com.lms.entities.Employee;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;
import com.lms.entities.User;

public interface EmployeeDao 
{
	
	public ResultSet employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException;
	public ResultSet viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException;
	
	public int requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException;
}
