package com.lms.dao;

import java.sql.SQLException;
import java.util.List;

import com.lms.entities.User;



public interface UserDAO {

	public List<User> getAllUsers()throws ClassNotFoundException, SQLException;
}
