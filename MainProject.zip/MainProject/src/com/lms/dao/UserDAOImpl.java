package com.lms.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lms.entities.User;
import com.lms.integrate.ConnectionManager;

public class UserDAOImpl implements UserDAO {

	@Override
	public List<User> getAllUsers() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select * from login");
		
		List<User> usersList=new ArrayList<User>();
		while(resultSet.next()) {
			User user=new User();
			user.setEmpId(resultSet.getString("user_Id"));
			user.setPassword(resultSet.getString("password"));
			usersList.add(user);
		}
		ConnectionManager.closeConnection();
		return usersList;
	}

}
