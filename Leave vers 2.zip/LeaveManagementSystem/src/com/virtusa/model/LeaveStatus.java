package com.virtusa.model;

public class LeaveStatus {

}
