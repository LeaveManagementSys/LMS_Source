package com.virtusa.view;

import java.util.Scanner;

public class ManagerView {


	public void managerHomePage() {
		Scanner sc=new Scanner(System.in);
		System.out.println("********Manager View*********");
		System.out.println("1.Check leave request");
		System.out.println("2.Logout");
		int opt1=sc.nextInt();
		System.out.println("wait for implementation");
	}
}
