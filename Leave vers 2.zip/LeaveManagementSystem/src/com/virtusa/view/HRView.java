package com.virtusa.view;

import java.util.Scanner;

public class HRView {

	public void hrHomePage() {
		Scanner sc= new Scanner (System.in);
		System.out.println("*********HR View********");
		System.out.println("1.Create employee");
		System.out.println("2.Delete employee");
		System.out.println("3.Upate details of employee");
		System.out.println("4.Track leave status");
		System.out.println("choose option");
		int opt1=sc.nextInt();
		System.out.println("under process wait for implmentation");
	}
}
