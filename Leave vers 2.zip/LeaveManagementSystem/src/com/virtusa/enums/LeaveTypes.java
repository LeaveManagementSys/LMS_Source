package com.virtusa.enums;
/*
 * need to implement whenever employee details is implemented
 * 
 */
public enum LeaveTypes {

}
