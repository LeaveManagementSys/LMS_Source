package com.virtusa.helper;

public class UserData {

}
