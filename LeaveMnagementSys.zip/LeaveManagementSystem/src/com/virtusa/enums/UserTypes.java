package com.virtusa.enums;

public class UserTypes {

}
