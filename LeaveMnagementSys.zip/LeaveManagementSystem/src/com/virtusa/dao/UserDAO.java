package com.virtusa.dao;

public interface UserDAO {

}
