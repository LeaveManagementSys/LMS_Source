package com.virtusa.dao;

public class UserDAOImp {

}
