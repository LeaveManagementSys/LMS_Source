package com.virtusa.services;

public interface HR {

}
