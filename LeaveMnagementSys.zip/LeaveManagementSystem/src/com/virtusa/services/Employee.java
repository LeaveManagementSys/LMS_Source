package com.virtusa.services;

public interface Employee {

}
