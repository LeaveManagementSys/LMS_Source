package com.virtusa.view;

public class ManagerView {

}
