package com.virtusa.entities;

public class Manager extends User {

}
