package com.virtusa.entities;

public class Employee extends User {

}
