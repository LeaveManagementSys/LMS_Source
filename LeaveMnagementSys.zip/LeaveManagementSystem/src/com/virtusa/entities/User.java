package com.virtusa.entities;

public class User {

}
