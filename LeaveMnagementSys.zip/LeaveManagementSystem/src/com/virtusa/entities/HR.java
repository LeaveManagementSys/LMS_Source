package com.virtusa.entities;

public class HR extends User{

}
