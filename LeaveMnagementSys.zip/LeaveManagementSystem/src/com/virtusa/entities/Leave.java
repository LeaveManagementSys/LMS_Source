package com.virtusa.entities;

public class Leave {

}
