package com.virtusa.exceptions;

public class UserException {

}
